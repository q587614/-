from fastapi import FastAPI
from app.routes import router
app = FastAPI(title='Hotel AI Commercial')
app.include_router(router)
