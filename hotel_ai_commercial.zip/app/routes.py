from fastapi import APIRouter
from pydantic import BaseModel
from app.workflow import run_workflow

router = APIRouter()

class LeadIn(BaseModel):
    text:str
    city:str='Tokyo'
    budget:int=1500
    nights:int=1
    source:str='xiaohongshu'

@router.get('/')
def home():
    return {'status':'ok'}

@router.post('/lead')
def lead(data: LeadIn):
    return run_workflow(data.dict())
