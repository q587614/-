import random, datetime

def intent_agent(ctx):
    txt=ctx['text'].lower()
    if 'hilton' in txt or '希尔顿' in txt:
        ctx['intent']='member_booking'
    elif 'cheap' in txt or '便宜' in txt:
        ctx['intent']='budget'
    else:
        ctx['intent']='general'
    return ctx

def pricing_agent(ctx):
    base=ctx['budget']*ctx['nights']
    rate=0.88 if ctx['intent']=='member_booking' else 0.95
    total=int(base*rate)
    ctx['quote']={
        'hotel': f"{ctx['city']} Grand Hotel",
        'total_price': total,
        'profit': int(total*0.12)
    }
    return ctx

def sales_agent(ctx):
    q=ctx['quote']
    ctx['message']=f"已为您锁定 {q['hotel']}，总价¥{q['total_price']}，现在预订可保留房态。"

    return ctx

def affiliate_agent(ctx):
    c=round(ctx['quote']['total_price']*0.08,2)
    ctx['affiliate']={'source':ctx['source'],'commission':c}
    return ctx

def retention_agent(ctx):
    ctx['next_action']='3天后发送复购优惠券'
    return ctx

def run_workflow(ctx):
    for fn in [intent_agent, pricing_agent, sales_agent, affiliate_agent, retention_agent]:
        ctx=fn(ctx)
    ctx['created_at']=str(datetime.datetime.utcnow())
    return ctx
