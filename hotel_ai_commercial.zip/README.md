# Hotel AI Commercial System

商业版多Agent酒店代订系统（FastAPI）

## 功能
- 多Agent协同：线索识别、报价、成交、分销、复购
- REST API
- SQLite 数据库
- 渠道佣金统计
- 客户线索管理

## 启动
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```
